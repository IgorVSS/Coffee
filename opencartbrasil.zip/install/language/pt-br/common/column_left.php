<?php
// Text
$_['text_license']       = 'Licença';
$_['text_installation']  = 'Pré-instalação';
$_['text_configuration'] = 'Configuração';
$_['text_upgrade']       = 'Atualizar';
$_['text_finished']      = 'Concluído';
$_['text_language']      = 'Idioma';
$_['text_en-gb']         = 'Inglês (Reino Unido)';
$_['text_pt-br']         = 'Português (Brasil)';
