<?php
class ModelMiddlewaresIp extends Model {
	public function hasBlocked($ip) {
		return false;
	}
}
